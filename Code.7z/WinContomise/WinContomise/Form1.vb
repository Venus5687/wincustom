﻿Imports System.IO
Imports System.Text
Public Class Form1
    Dim prgm As String
    Dim prgm2 As String
    Dim args As String
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button2.Visible = True
        Button3.Visible = True
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        PictureBox2.Visible = False
        Button2.Visible = True
        Label1.Visible = True
        Button3.Visible = True
        Label3.Visible = False
        Label4.Visible = False
        Button4.Visible = False
        Button5.Visible = False
        Button6.Visible = False
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Button2.Visible = False
        Button3.Visible = False
        Label1.Visible = False
        PictureBox2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Button4.Visible = True
        Button5.Visible = True
        Button6.Visible = True
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Process.Start("https://www.wincert.net/forum/topic/15057-win-toolkit-current-version-17015/")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        OpenFileDialog1.ShowDialog()
        Process.Start(OpenFileDialog1.FileName)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Panel1.Visible = True
        Button8.Enabled = False
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        OpenFileDialog2.ShowDialog()
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        TextBox1.Text = OpenFileDialog2.FileName
        System.Diagnostics.Process.Start(prgm, ControlChars.Quote & TextBox1.Text & ControlChars.Quote)
        Button8.Enabled = True
    End Sub

    Private Sub OpenFileDialog2_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog2.FileOk

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox2.Show()
        Button9.Show()
        Button10.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, ControlChars.Quote & OpenFileDialog2.FileName & TextBox2.Text & ControlChars.Quote)
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, ControlChars.Quote & OpenFileDialog2.FileName & "\sources" & ControlChars.Quote)
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, ControlChars.Quote & OpenFileDialog2.FileName & "\sources\license" & ControlChars.Quote)
        If OpenFileDialog2.FileName.Contains("6.2") Then
            MsgBox("This feature is not available in a Windows 8 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
        If OpenFileDialog2.FileName.Contains("windows_8") Then
            MsgBox("This feature is not available in a Windows 8 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
        If OpenFileDialog2.FileName.Contains("Win8") Then
            MsgBox("This feature is not available in a Windows 8 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
        If OpenFileDialog2.FileName.Contains("10.0") Then
            MsgBox("This feature is not available in a Windows 10 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
        If OpenFileDialog2.FileName.Contains("windows_10") Then
            MsgBox("This feature is not available in a Windows 10 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
        If OpenFileDialog2.FileName.Contains("Win10") Then
            MsgBox("This feature is not available in a Windows 10 ISO yet!", MsgBoxStyle.Information, "Hold on...")
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Button2.Visible = True
        Label1.Visible = True
        Button3.Visible = True
        PictureBox3.Hide()
        Label7.Hide()
        Label6.Hide()
        Button14.Hide()
        Button13.Hide()
        Button12.Hide()
        Button11.Hide()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        PictureBox3.Show()
        Label7.Show()
        Label6.Show()
        Button13.Show()
        Button12.Show()
        Button11.Show()
        Button14.Show()
        Button2.Visible = False
        Button3.Visible = False
        Label1.Visible = False
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, ControlChars.Quote & OpenFileDialog2.FileName & "\sources\en-us" & ControlChars.Quote)
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Date.Now.Day = 19 Then
            End
        End If
    End Sub
End Class
