﻿Public Class Form1
    Dim prgm As String
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button2.Visible = True
        Button3.Visible = True
        Label6.Show()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        PictureBox2.Visible = False
        Button2.Visible = True
        Label1.Visible = True
        Button3.Visible = True
        Label3.Visible = False
        Label4.Visible = False
        Button4.Visible = False
        Button5.Visible = False
        Button6.Visible = False
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Button2.Visible = False
        Button3.Visible = False
        Label1.Visible = False
        PictureBox2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Button4.Visible = True
        Button5.Visible = True
        Button6.Visible = True
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Process.Start("https://www.wincert.net/forum/topic/15057-win-toolkit-current-version-17015/")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        OpenFileDialog1.ShowDialog()
        Process.Start(OpenFileDialog1.FileName)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Panel1.Visible = True
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        OpenFileDialog2.ShowDialog()
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        TextBox1.Text = OpenFileDialog2.FileName
        System.Diagnostics.Process.Start(prgm, TextBox1.Text)
        Button8.Enabled = True
    End Sub

    Private Sub OpenFileDialog2_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog2.FileOk

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Button9.Show()
        Button10.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, OpenFileDialog2.FileName & "\sources\install.wim")
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        prgm = "C:\Program Files\7-Zip\7zFM.exe"
        System.Diagnostics.Process.Start(prgm, OpenFileDialog2.FileName & "\sources\boot.wim")
    End Sub
End Class
